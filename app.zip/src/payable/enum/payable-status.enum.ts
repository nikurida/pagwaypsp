export enum PayableStatus {
  Pending = 'pending',
  Settled = 'paid',
}
