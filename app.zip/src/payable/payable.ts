export class Payable {
  readonly id: number;
  readonly status: string;
  readonly paymentDate: Date;
  readonly amount: number;
}
