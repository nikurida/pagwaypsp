export class Transaction {
  id: number;
  amount: number;
  customerId: number;
  description: string;
  cardLastFour: string;
  createdAt: Date;
}
