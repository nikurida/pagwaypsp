export class Balance {
  readonly customerId: number;
  readonly paid: number;
  readonly available: number;
}
